function validateForm(){
    let x = document.forms["myForm"]["fname"].value;

    if(x == ""){
        alert("Name Must be Filled");
        return false;
    }
}
function validateForm(){
    let x = document.forms["myForm"]["lname"].value;

    if(x == ""){
        alert("Surname Must be Filled");
        return false;
    }
}
function validateForm(){
    let x = document.forms["myForm"]["email"].value;

    if(x == ""){
        alert("Invalid Email");
        return false;
    }
    else["submit"]
        alert("Valid Email");
        return true;
    }
    onclick(ok)

